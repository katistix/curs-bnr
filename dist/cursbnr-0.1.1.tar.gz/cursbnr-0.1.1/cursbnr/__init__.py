from .bnr import getRates
